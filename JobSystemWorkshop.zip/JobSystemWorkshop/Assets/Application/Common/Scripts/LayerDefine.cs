﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Layerの定義です
public class LayerDefine {
    //　背景レイヤー
    public const int BG = 9;
    // キャラレイヤー
    public const int CHARA = 10;
    // 影レイヤー
    public const int SHADOW = 11;
}
